gitlab_server = "https://gitlab.com"
gitlab_project_id = 53435816
gitlab_token = "glpat-aJYks8k4_moTNCwzTsMy"