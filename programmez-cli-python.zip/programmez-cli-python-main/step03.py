# Use of a configuration file
# Expose a value from the configuration file in a command
# Set a specific name for your command
import typer
import config

app = typer.Typer()


@app.command()
def hello(name: str):
    print(f"Hello {name}")


@app.command("project")
def gitlab_project():
    print(f"Hello {config.gitlab_project_id}")


if __name__ == "__main__":
    app()
