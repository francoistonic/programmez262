# add description for the command line help
# use the GitLab API to get the list of todo items from a project
# expose the number of todo items
import typer
import config
import gitlab

app = typer.Typer()

# Function to get todos from GitLab
def get_gitlab_todos():
    # Initialize GitLab
    gl = gitlab.Gitlab(url=config.gitlab_server, private_token=config.gitlab_token)

    # Get todos
    todos = gl.todos.list(project_id=config.gitlab_project_id, all=True)
    return [todo.attributes for todo in todos]


@app.command("howmany")
def todo_how_many():
    """
    Show the number of items in the todo list
    """
    todos = get_gitlab_todos()
    print(len(todos))


@app.command("project")
def gitlab_project():
    """
    Show the GitLab project ID that will be used
    """
    print(f"Hello {config.gitlab_project_id}")


if __name__ == "__main__":
    app()
