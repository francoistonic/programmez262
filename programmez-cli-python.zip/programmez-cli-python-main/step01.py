# from the Typer project documentation
# it is the simplest form of usage of Typer
import typer


def main(name: str):
    print(f"Hello {name}")


if __name__ == "__main__":
    typer.run(main)
