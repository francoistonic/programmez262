#!/bin/bash

java -jar ../../../target/quarkus-app/quarkus-run.jar $1 $2 $3