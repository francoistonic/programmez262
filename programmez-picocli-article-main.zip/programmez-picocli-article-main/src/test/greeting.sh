#!/bin/bash

java -Dquarkus.log.console.enable=false -jar ../../target/quarkus-app/quarkus-run.jar $1