# fichier test_function_app.py

import azure.functions as func
from function_app import hello


def test_hello():
    # mock d'une requête HTTP
    req = func.HttpRequest(
        method="GET", body=None, url="/hello_get", params={"name": "programmez"}
    )

    # construction de la fonction à partir du décorateur
    func_call = hello.build().get_user_function()

    # invocation du service
    response = func_call(req)

    # vérification de la réponse
    assert response.get_body() == b"Hello, programmez !"
