# fichier function_app.py

import azure.functions as func

# instanciation de la Function App qui va contenir les fonctions
app = func.FunctionApp()


# utilisation d'un décorateur python pour binder la fonction sur la ressource HTTP /hello
@app.route(route="hello", auth_level=func.AuthLevel.FUNCTION)
def hello(req: func.HttpRequest) -> func.HttpResponse:
    # récupération du paramètre HTTP user à partir de la requête
    name = req.params.get("name")

    return func.HttpResponse(f"Hello, {name} !")
