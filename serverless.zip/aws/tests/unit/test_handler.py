# fichier tests/test_handler.py
from hello_world import app


def test_lambda_handler():
    # invocation du service
    response = app.lambda_handler(
        {"queryStringParameters": {"name": "programmez !"}}, None
    )

    # vérification de la réponse
    assert response["body"] == "hello programmez !"
