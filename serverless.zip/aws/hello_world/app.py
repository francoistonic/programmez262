# extrait du fichier hello_world/app.py


def lambda_handler(event, context):
    name = event["queryStringParameters"]["name"]

    return {"statusCode": 200, "body": f"hello {name}"}
