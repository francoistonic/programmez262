# fichier test_main.py

from main import hello_get
import flask

app = flask.Flask(__name__)


def test_hello_get():
    # context de test pour la création de la requête
    with app.test_request_context("?name=programmez") as req:
        # invocation du service
        response = hello_get(req.request)

        # vérification de la réponse
        assert response[0] == "Hello, programmez !"
