# Extrait du fichier main.py

import functions_framework
from flask import Request
from flask.typing import ResponseReturnValue


@functions_framework.http
def hello_get(request: Request) -> ResponseReturnValue:
    name = request.args.get("name")

    return f"Hello, {name} !", 200
